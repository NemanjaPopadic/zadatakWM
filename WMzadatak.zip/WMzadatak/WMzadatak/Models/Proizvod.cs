﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WMzadatak.Models
{
    public class Proizvod
    {
        public int id { get; set; }
        public string naziv { get; set; }
        public string opis { get; set; }
        public string kategorija { get; set; }
        public string proizovdjac { get; set; }
        public string dobavljac { get; set; }
        public decimal cena { get; set; }

    }

  public class Proizvodjac
    {
        public string Name { get; set; }
    }
    public class Prodavnica
    {
        public List<Proizvod> proizvod { get; set; }
        public Proizvodjac  proizvodjac { get; set; }
        public ErrorClass err { get; set; }
    }
    public class ErrorClass
    {
        public string Error { get; set; }
    }
}