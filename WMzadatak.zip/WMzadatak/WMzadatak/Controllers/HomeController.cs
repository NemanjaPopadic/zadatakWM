﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WMzadatak.Models;
namespace WMzadatak.Controllers
{
    public class HomeController : Controller
    {
        string  conString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\np250217\source\repos\WMzadatak\WMzadatak\App_Data\WMzadatak.mdf;Integrated Security=True";
        public ActionResult Index()
        {
            List<Proizvod> proizvods = new List<Proizvod>();
            Prodavnica pr = new Prodavnica();
            ErrorClass er = new ErrorClass();
           
            SqlConnection con = new SqlConnection(conString);
            SqlCommand com = new SqlCommand("SELECT Id,naziv,opis,kategorija,proizvodjac,dobavljac,cena FROM Proizvod", con);
            try
            {
                if (con.State == System.Data.ConnectionState.Closed) { con.Open(); }
                if (con.State == System.Data.ConnectionState.Open)
                {
                    SqlDataReader read = com.ExecuteReader();
                    while (read.Read())
                    {
                        Proizvod p = new Proizvod();
                        p.id = Convert.ToInt32(read["Id"]);
                        p.naziv = Convert.ToString(read["naziv"]);
                        p.opis = Convert.ToString(read["opis"]);
                        p.kategorija = Convert.ToString(read["kategorija"]);
                        p.proizovdjac = Convert.ToString(read["proizvodjac"]);
                        p.dobavljac = Convert.ToString(read["dobavljac"]);
                        p.cena = Convert.ToDecimal(read["cena"]);
                        proizvods.Add(p);

                    }
                    pr.proizvod=proizvods;
                    Proizvodjac proiz = new Proizvodjac();
                    proiz.Name = "Test";
                    pr.proizvodjac = proiz;
                    er.Error = null;
                }
            }catch(Exception ex)
            {
                er.Error = "error je : " + ex.Message;
                pr.err = er;
                return View(pr);

                
            }
            finally
            {
                if(con.State== System.Data.ConnectionState.Open)
                con.Close();
            }
            return View(pr);
        }
        [HttpGet]
        public ActionResult Izmena(int id)
        {

            return View(id);
        }
        [HttpGet]
        public ActionResult Insert()
        {
            return View();
        }
        [HttpPost]
        public ActionResult UpdateProizvod(Proizvod proizvod)
        {
            int id = proizvod.id;
            SqlConnection con = new SqlConnection(conString);
            SqlCommand com = new SqlCommand("Update  Proizvod  set naziv=@nz, opis=@op,kategorija=@kat,proizvodjac=@proiz,dobavljac=@dob,cena=@cn where Id=@id",con);
            com.Parameters.AddWithValue("@id", proizvod.id);
            com.Parameters.AddWithValue("@nz", proizvod.naziv);
            com.Parameters.AddWithValue("@op", proizvod.opis);
            com.Parameters.AddWithValue("@kat", proizvod.kategorija);
            com.Parameters.AddWithValue("@proiz", proizvod.proizovdjac);
            com.Parameters.AddWithValue("@dob", proizvod.dobavljac);
            com.Parameters.AddWithValue("@cn", Convert.ToDecimal(proizvod.cena));
            try
            {
                if (con.State == System.Data.ConnectionState.Closed) { con.Open(); }
                if (con.State == System.Data.ConnectionState.Open)
                {
                    int updated = com.ExecuteNonQuery();
                    if (updated > 0)
                    {
                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                       
                        return RedirectToAction("Izmena", "Home", new { id });
                    }
                }
            }
            catch (Exception ex)
            {
                return RedirectToAction("Izmena", "Home", new { id });
            }
            finally
            {
                if(con.State== System.Data.ConnectionState.Open) { con.Close(); }
            }

            return RedirectToAction("Izmena", "Home", new { id });
        }
     
        [HttpPost]
        public ActionResult InsertProizvod(Proizvod proizvod)
        {
           
            SqlConnection con = new SqlConnection(conString);
            SqlCommand com = new SqlCommand("Insert into  Proizvod  (naziv,opis,kategorija,proizvodjac,dobavljac,cena) values(@nz,@op,@kat,@proiz,@dob,@cn)", con);
           
            com.Parameters.AddWithValue("@nz", proizvod.naziv);
            com.Parameters.AddWithValue("@op", proizvod.opis);
            com.Parameters.AddWithValue("@kat", proizvod.kategorija);
            com.Parameters.AddWithValue("@proiz", proizvod.proizovdjac);
            com.Parameters.AddWithValue("@dob", proizvod.dobavljac);
            com.Parameters.AddWithValue("@cn", Convert.ToDecimal(proizvod.cena));
            try
            {
                if (con.State == System.Data.ConnectionState.Closed) { con.Open(); }
                if (con.State == System.Data.ConnectionState.Open)
                {
                    int updated = com.ExecuteNonQuery();
                    if (updated > 0)
                    {
                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        return RedirectToAction("Index", "Home");
                    }
                }
            }
            catch (Exception ex)
            {
                return RedirectToAction("Index", "Home");
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open) { con.Close(); }
            }

            return RedirectToAction("Index", "Home");
        }
    }
    
    
}